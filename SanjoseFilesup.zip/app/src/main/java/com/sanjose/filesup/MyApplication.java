package com.sanjose.filesup;

import android.app.Application;
import android.content.Context;

import com.sanjose.filesup.Base.Album;
import com.sanjose.filesup.Base.HandlingAlbums;

/**
 *
 */
public class MyApplication extends Application {

    static Context context1;
    private HandlingAlbums albums;

    public static Context getContext() {
        return context1;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        context1 = getApplicationContext();
    }

    Album getCurrentAlbum() {

        return albums.getCurrentAlbum();
    }

    void removeCurrentAlbum() {
        albums.removeCurrentAlbum();
    }

    public HandlingAlbums getAlbums() {

        return albums;
    }

    public void setAlbums(HandlingAlbums albums) {

        this.albums = albums;
    }

    void updateAlbums() {

        albums.loadPreviewAlbums(getApplicationContext());
    }
}
