package com.sanjose.filesup.utils;

/**
 */
public class PreferenceUtil {
}
