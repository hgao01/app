package com.sanjose.filesup.utils;

/**
 */
class Constants {
    static int ALBUM_CARD_WIDTH = 1200;
    static int PHOTO_CARD_WIDTH = 900;
}
