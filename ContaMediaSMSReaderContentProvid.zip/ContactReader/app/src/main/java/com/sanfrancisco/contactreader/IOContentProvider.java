package com.sanfrancisco.contactreader;

/**
 * Created by hgao01
 */


        import android.app.Activity;
        import android.content.ContentResolver;
        import android.content.ContentValues;
        import android.database.Cursor;
        import android.net.Uri;
        import android.os.Bundle;
        import android.view.View;
        import android.view.View.OnClickListener;
        import android.widget.Button;
        import android.widget.EditText;
        import android.widget.Toast;

        import com.sanfrancisco.contactreader.providers.CompContentProvider;
        import com.sanfrancisco.contactreader.providers.CompDBHper;



public class IOContentProvider extends Activity {
    private static ContentResolver ContRes3;
    String msg = null;
    private EditText etCusNo, etCusNa, etCusPho, etCusAdd;
    private EditText etResult;
    private Button btIns, btCls, btList;
    private Button btQry, btEdit, btDel;



    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.iocontent_view);
        buildViews();  //user define
        ContRes3 = getContentResolver();
    }

    private void buildViews() {
        etCusNo = (EditText) findViewById(R.id.etIdCusNo);
        etCusNa = (EditText) findViewById(R.id.etIdCusNa);
        etCusPho = (EditText) findViewById(R.id.etIdCusPho);
        etCusAdd = (EditText) findViewById(R.id.etIdCusAdd);

        etResult = (EditText) findViewById(R.id.etIdResult);

        btIns = (Button) findViewById(R.id.btIdIns);
        btCls = (Button) findViewById(R.id.btIdCls);
        btList = (Button) findViewById(R.id.btIdList);
        btQry = (Button) findViewById(R.id.btIdQry);
        btEdit = (Button) findViewById(R.id.btIdEdit);
        btDel = (Button) findViewById(R.id.btIdDel);

        btIns.setOnClickListener(btInsListener);
        btCls.setOnClickListener(btClsListener);
        btList.setOnClickListener(btListListener);
        btQry.setOnClickListener(btQryListener);
        btEdit.setOnClickListener(btEditListener);
        btDel.setOnClickListener(btDelListener);
    }

    private ContentValues GetRecords() {  //user define method, getting io data
        ContentValues contVal = new ContentValues();
        contVal.put("cusNo", etCusNo.getText().toString());
        contVal.put("cusNa", etCusNa.getText().toString());
        contVal.put("cusPho", etCusPho.getText().toString());
        contVal.put("cusAdd", etCusAdd.getText().toString());
        return contVal;
    }




    private OnClickListener btInsListener = new OnClickListener() {
        public void onClick(View v) {
            ContentValues contVal = new ContentValues();
            Uri uri = CompContentProvider.CONTENT_URI;
            contVal = GetRecords();
            ContRes3.insert(uri, contVal);
        }
    };
    private OnClickListener btClsListener = new OnClickListener() {
        public void onClick(View v) {
            etCusNo.setText("");
            etCusNa.setText("");
            etCusPho.setText("");
            etCusAdd.setText("");
        }
    };
    private OnClickListener btListListener = new OnClickListener() {
        public void onClick(View v) {
            Uri uri = CompContentProvider.CONTENT_URI;
            String[] projection = new String[]{"cusNo", "cusNa", "cusPho", "cusAdd"};
            String selection = null;
            String[] selectionArgs = null;
            String sortOrder = null;
            Cursor cur = ContRes3.query(uri, projection, selection, selectionArgs, sortOrder);

            if (cur == null) return;
            if (cur.getCount() == 0) {
                etResult.setText("");
                Toast.makeText(IOContentProvider.this, "No Data", Toast.LENGTH_LONG).show();
            } else {
                cur.moveToFirst();
                etResult.setText(cur.getString(0) + " " +
                        cur.getString(1) + " " + cur.getString(2) + " " + cur.getString(3));

                while (cur.moveToNext())
                    etResult.append("\n" + cur.getString(0) + " " +
                            cur.getString(1) + " " + cur.getString(2) + " " + cur.getString(3));
                Toast.makeText( IOContentProvider.this, "Total " + cur.getCount() + " records", Toast.LENGTH_LONG)
                        .show();
            }
        }
    };
    private OnClickListener btQryListener = new OnClickListener() {
        public void onClick(View v) {

            Cursor cur = null;
            if (etCusNo.getText().toString().isEmpty() == false) {
                Uri uri = CompContentProvider.CONTENT_URI;
                String[] projection = new String[]{"cusNo", "cusNa", "cusPho", "cusAdd"};
                String selection = "cusNo=" + "\'" + etCusNo.getText().toString() + "\'";
                String[] selectionArgs = null;
                String sortOrder = null;
                cur = ContRes3.query(uri, projection, selection, selectionArgs, sortOrder);
            } else {
                Toast.makeText( IOContentProvider.this,
                        "Client number is empty? We only use Client number to query !", Toast.LENGTH_LONG)
                        .show();
            }

            if (cur == null) return;
            if (cur.getCount() == 0) {
                etResult.setText("");
                Toast.makeText( IOContentProvider.this, "No Data", Toast.LENGTH_LONG).show();
            } else {
                cur.moveToFirst();
                etCusNo.setText(cur.getString(0));
                etCusNa.setText(cur.getString(1));
                etCusPho.setText(cur.getString(2));
                etCusAdd.setText(cur.getString(3));
            }
        }
    };
    private OnClickListener btEditListener = new OnClickListener() {
        public void onClick(View v) {

            Uri uri = CompContentProvider.CONTENT_URI;
            ContentValues contVal = new ContentValues();
            contVal = GetRecords();
            String CusNo = etCusNo.getText().toString().trim();
            String whereClause = "cusNo='" + CusNo + "'";
            String[] selectionArgs = null;
            int rowsAffected =
                    ContRes3.update(uri, contVal, whereClause, selectionArgs);
            if (rowsAffected == -1) {
                msg = " The table is empty, un-changable !";
            } else if (rowsAffected == 0) {
                msg = "No records are found, un-changable !";
            } else {
                msg = "Total " + rowsAffected + " records   are updated !";
            }
            Toast.makeText( IOContentProvider.this, msg, Toast.LENGTH_SHORT).show();

        }
    };
    private OnClickListener btDelListener =
            new OnClickListener() {
                public void onClick(View v) {

                    Uri uri = CompContentProvider.CONTENT_URI;
                    String CusNo = etCusNo.getText().toString().trim();
                    String whereClause = "cusNo='" + CusNo + "'";
                    String[] selectionArgs = null;
                    int rowsAffected = ContRes3.delete(uri, whereClause, selectionArgs);

                    if (rowsAffected == -1) {
                        msg = "The table si empty, un-changable !";
                    } else if (rowsAffected == 0) {
                        msg = "No records found, unable to delete !";
                    } else {
                        msg = "Now " + rowsAffected + " records   are deleted !";
                    }
                    Toast.makeText( IOContentProvider.this, msg, Toast.LENGTH_SHORT).show();

                }
            };
}







