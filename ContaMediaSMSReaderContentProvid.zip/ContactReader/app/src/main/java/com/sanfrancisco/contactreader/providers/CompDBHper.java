package com.sanfrancisco.contactreader.providers;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteDatabase.CursorFactory;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.Toast;

import com.sanfrancisco.contactreader.IOContentProvider;

public class CompDBHper extends SQLiteOpenHelper {
    //private static final String DBname = "AdvancedCo.db";
    //private static final int DBversion = 1;
    private static final String TBname = "Client";
    private static final String crTBsql =
            "CREATE TABLE " + TBname + " ( " +
                    " cusNo VARCHAR(10) NOT NULL, " +
                    " cusNa VARCHAR(20) NOT NULL, " +
                    " cusPho VARCHAR(20), " +
                    " cusAdd VARCHAR(50), PRIMARY KEY (cusNo)); ";

    //INSERT INTO Customers (CustomerName, ContactName, Address, City, PostalCode, Country)
    // VALUES ('Cardinal','Tom B. Erichsen','Skagen 21','Stavanger','4006','Norway');

    private static final String insTBsql =
            "INSERT INTO " + TBname + " VALUES ( " + " \'111\', " + " \'222cusNa\', " +
                    " \'333cusPho\', " + " \'444cusAdd\' " + "); ";

    @Override
    public void onCreate(SQLiteDatabase db) {

        db.execSQL(crTBsql);
        db.execSQL( insTBsql );
        System.out.println("DB created !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
        //Toast.makeText(CompDBHper.this, "DB is created.", Toast.LENGTH_LONG).show();
    }

    public CompDBHper(Context context1, String DBname1,
                      CursorFactory factory1, int DBversion1) {
//		super(context1, DBname1, null, DBversion1);
        super(context1, "AdvancedCo.db", null, 1);
    }


    @Override
    public void onUpgrade(SQLiteDatabase db,
                          int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TBname);
        onCreate(db);
    }
}