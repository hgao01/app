package com.sanfrancisco.contactreader;

import android.app.Activity;
import android.content.ContentResolver;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.provider.MediaStore;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;
import android.widget.Toast;

public class MainActivity extends Activity {

    private static ContentResolver ContRes;
    private static ContentResolver ContRes2;
    private ListView lvContacts;
    private ListView lvMedia;



    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);

        readingMediaSD();
        //readingContacts();
    }


    protected void readingMediaSD()  {

        lvMedia = (ListView) findViewById(R.id.lvIdMedia);

        ContRes = getContentResolver();
        Uri uri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
        grantUriPermission("com.sanfrancisco.contactreader", uri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
        String[] projection = null;
        String selection = null;
        String[] selectionArgs = null;
        String sortOrder = null;
        Cursor cur = ContRes.query(uri, projection, selection, selectionArgs, sortOrder);


        @SuppressWarnings("deprecation")
        SimpleCursorAdapter simpleCursorAdapter = new SimpleCursorAdapter(this,
                android.R.layout.simple_list_item_1, cur, new String[]
                {MediaStore.Audio.Media.ALBUM}, new int[]
                {android.R.id.text1});
        lvMedia.setAdapter(simpleCursorAdapter);


        startManagingCursor(cur);
        int albumIdx = cur.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM);
        int titleIdx = cur.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE);

        String[] result = new String[cur.getCount()];
        if (cur.moveToFirst())
            do {
                String title = cur.getString(titleIdx);//Song
                String album = cur.getString(albumIdx);//CD
                result[cur.getPosition()] = title + " (" + album + ")";
                Toast.makeText(this, result[cur.getPosition()], Toast.LENGTH_SHORT).show();
            } while (cur.moveToNext());
        stopManagingCursor(cur);
    }



    protected void readingContacts() {
        lvContacts = (ListView) findViewById(R.id.lvIdContacts);

        ContRes2 = getContentResolver();
        Uri uri = ContactsContract.Contacts.CONTENT_URI;
        String[] projection = null;
        String selection = null;
        String[] selectionArgs = null;
        String sortOrder = null;
        Cursor cur = ContRes2.query(uri, projection, selection, selectionArgs, sortOrder);
        @SuppressWarnings("deprecation")
        SimpleCursorAdapter simpleCursorAdapter =
                new SimpleCursorAdapter(this,
                        android.R.layout.simple_list_item_1, cur, new String[]
                        {ContactsContract.Contacts.DISPLAY_NAME}, new int[]
                        {android.R.id.text1});

        lvContacts.setAdapter(simpleCursorAdapter);
    }


}


