/*    */


package com.sanfrancisco.android.silentmodetoggle;

import android.graphics.drawable.Drawable;
import android.media.AudioManager;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {
    private AudioManager mAudioManager1;
    private boolean mPhoneIsSilent1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mAudioManager1 = (AudioManager) getSystemService(AUDIO_SERVICE);

        checkIfPhoneIsSilent1();
        setButtonClickListener1();
    }


    private void setButtonClickListener1() {
        Button toggleButton1 = (Button) findViewById(R.id.toggleButton);
        toggleButton1.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v1) {
                if (mPhoneIsSilent1) {
                    // Change back to normal mode
                    mAudioManager1.setRingerMode(AudioManager.RINGER_MODE_NORMAL);
                    mPhoneIsSilent1 = false;
                } else {
                    // Change to silent mode
                    mAudioManager1.setRingerMode(AudioManager.RINGER_MODE_SILENT);
                    mPhoneIsSilent1 = true;
                }
                // Now toggle the UI again
                drawAppUi1();
            }
        });
    }

    /**
     * Checks to see if the phone is currently in silent mode.
     */
    private void checkIfPhoneIsSilent1() {
        int ringerMode1 = mAudioManager1.getRingerMode();
        if (ringerMode1 == AudioManager.RINGER_MODE_SILENT) {
            mPhoneIsSilent1 = true;
        } else {
            mPhoneIsSilent1 = false;
        }
    }

    /**
     * Toggles the UI images from silent to normal and vice versa.
     */
    private void drawAppUi1() {
        ImageView imageView1 = (ImageView) findViewById(R.id.phone_icon);
        Drawable newPhoneImage1;
        if (mPhoneIsSilent1) {
            newPhoneImage1 = getResources().getDrawable(R.drawable.phone_silent);
        } else {
            newPhoneImage1 = getResources().getDrawable(R.drawable.phone_on);
        }

        imageView1.setImageDrawable(newPhoneImage1);
    }

    @Override
    protected void onResume() {
        super.onResume();
        checkIfPhoneIsSilent1();
        drawAppUi1();
    }
}
