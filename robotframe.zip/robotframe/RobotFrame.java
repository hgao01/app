package robotframe;

/**
 * @author George 2016
 */
import java.awt.*;
import java.awt.event.*;  
import java.util.*;

import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.InputStream;

import javax.swing.*;
import javax.swing.Timer;
import javax.imageio.ImageIO;

import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JCheckBoxMenuItem;
import javax.swing.JRadioButtonMenuItem;
import javax.swing.ButtonGroup;
import javax.swing.JMenuBar;
import javax.swing.KeyStroke;
import javax.swing.ImageIcon;

import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JScrollPane;
import javax.swing.JFrame;



public class RobotFrame {

    public static void main(String[] args) {

        RobotFrame1 frame1 = new RobotFrame1();
        frame1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame1.setVisible(true);

        ActionListener heartbeatActions1 = new HeartBeateralways1();
        // construct a timer that calls the listener;  once every 3 seconds
        Timer t1 = new Timer(3000, heartbeatActions1);
        t1.start();

    }

}

/**
 * An action listener for the whole application, always running
 */
class HeartBeateralways1 implements ActionListener {

    public void actionPerformed(ActionEvent event3) {
        Date now1 = new Date();
        System.out.println("At the tone, the time is " + now1);
        Toolkit.getDefaultToolkit().beep();
    }
}

/**
 * One frame with one button panel
 */
class RobotFrame1 extends JFrame {

    public static final int WIDTH1 = 500;
    public static final int HEIGHT1 = 500;
    public static final String imagePath1 = "image10png.png"; // the path is relative to ".class" file
    public BufferedImage bufferedImage1;

    public RobotFrame1() {
        setTitle("Heart Beating, Menu bar, and Buttons ");
        setSize(WIDTH1, HEIGHT1);

        MenuBarDesign1 mlo1 = new MenuBarDesign1();
        setJMenuBar(mlo1.createMenuBar1());

        // add a panel to this frame
        RobotPanel1 panel1 = new RobotPanel1();

        Container contentPane1 = getContentPane();

        contentPane1.add(panel1);

        try {
            InputStream imageInputStream1 = getClass().getResourceAsStream(imagePath1);

            bufferedImage1 = ImageIO.read(imageInputStream1);
            setIconImage(bufferedImage1);
        } catch (IOException exception1) {
            exception1.printStackTrace();
        }

    }

}

/**
 * A panel with buttons.
 */
class RobotPanel1 extends JPanel {

    public static final String imagePath1 = "image10png.png"; // the path is relative to ".class" file
    public BufferedImage bufferedImage1;

    public RobotPanel1() {
        // create buttons; add buttons to panel ; create button actions;  associate actions with buttons;

        JButton yellowButton1 = new JButton("Yellow");
        Button1Action1 yellowAction1 = new Button1Action1(Color.orange);
        add(yellowButton1);
        yellowButton1.addActionListener(yellowAction1);

        JButton blueButton1 = new JButton("Blue");
        add(blueButton1);
        Button1Action1 blueAction = new Button1Action1(Color.blue);
        blueButton1.addActionListener(blueAction);

        JButton exitButton1 = new JButton("Exit");
        add(exitButton1);
        Exitbutton1Action1 exitButton1Action1 = new Exitbutton1Action1();
        exitButton1.addActionListener(exitButton1Action1);

        try {
            InputStream imageInputStream1 = getClass().getResourceAsStream(imagePath1);

            bufferedImage1 = ImageIO.read(imageInputStream1);
            //setIconImage(bufferedImage1);
        } catch (IOException exception1) {
            exception1.printStackTrace();
        }

    }

    /**
     * An action listener, only sets the panel background color, after click
     * event
     */
    private class Button1Action1 implements ActionListener {

        private Color backgroundColor1;

        public Button1Action1(Color c1) {
            backgroundColor1 = c1;
        }

        public void actionPerformed(ActionEvent event1) {
            setBackground(backgroundColor1);

            repaint();
            //Toolkit.getDefaultToolkit().beep();
        }

    }

    /**
     * An action listener for the EXIT button, exits the program after click
     */
    private class Exitbutton1Action1 implements ActionListener {

        public Exitbutton1Action1() {
            //Toolkit.getDefaultToolkit().beep();
        }

        public void actionPerformed(ActionEvent clickit1) {

            String message = "Really quit?";
            String title = "Please answer :";
            int reply1 = JOptionPane.showConfirmDialog(null, message, title, JOptionPane.YES_NO_OPTION);
            if (reply1 == JOptionPane.YES_OPTION) {
                System.exit(0);
            }
            //Toolkit.getDefaultToolkit().beep();    
        }

    }

    // use it inside a JPanel; Draw the bg pic here
    public void paintComponent(Graphics g1) {
        super.paintComponent(g1);
        // Draw the background image.

        g1.drawImage(bufferedImage1, 0, 90, this);
    }

}



class MenuBarDesign1 {

    //JTextArea output;
    //JScrollPane scrollPane;

    public JMenuBar createMenuBar1() {
        JMenuBar menuBar;       //horozontal
        JMenu menu, submenu;    // vertical
        JMenuItem menuItem;     // each option item
        JRadioButtonMenuItem rbMenuItem;
        JCheckBoxMenuItem cbMenuItem;

        //Create the menu bar.
        menuBar = new JMenuBar();

        //Build the first menu.
        menu = new JMenu("1st Menu");
        menu.setMnemonic(KeyEvent.VK_A );
        menu.getAccessibleContext().setAccessibleDescription(
                "The menu that has menu items");
        menuBar.add(menu);

        //a group of JMenuItems , #1
        menuItem = new JMenuItem("Text-only item, no ICON", KeyEvent.VK_T  );
        //menuItem.setMnemonic(KeyEvent.VK_T); //used constructor instead
        menuItem.setAccelerator(KeyStroke.getKeyStroke( KeyEvent.VK_1 , ActionEvent.ALT_MASK));
        menuItem.getAccessibleContext().setAccessibleDescription( "This doesn't really do anything");
        menu.add(menuItem);
        // #2
        ImageIcon icon = createImageIcon1("menulookdemo.gif");
        menuItem = new JMenuItem("Both text and icon", icon);
        menuItem.setMnemonic(KeyEvent.VK_B);
        menu.add(menuItem);
        // #3
        menuItem = new JMenuItem(icon);
        menuItem.setMnemonic(KeyEvent.VK_D);
        menu.add(menuItem);
        //#4
        //a group of radio button menu items
        menu.addSeparator();
        ButtonGroup group = new ButtonGroup();

        rbMenuItem = new JRadioButtonMenuItem("A radio button menu item");
        rbMenuItem.setSelected(true);
        rbMenuItem.setMnemonic(KeyEvent.VK_R);
        group.add(rbMenuItem);
        menu.add(rbMenuItem);
        //#5
        rbMenuItem = new JRadioButtonMenuItem("Another one");
        rbMenuItem.setMnemonic(KeyEvent.VK_O);
        group.add(rbMenuItem);
        menu.add(rbMenuItem);
        //#6
        //a group of check box menu items
        menu.addSeparator();
        cbMenuItem = new JCheckBoxMenuItem("A check box menu item");
        cbMenuItem.setMnemonic(KeyEvent.VK_C);
        menu.add(cbMenuItem);
        //#7
        cbMenuItem = new JCheckBoxMenuItem("Another one");
        cbMenuItem.setMnemonic(KeyEvent.VK_H);
        menu.add(cbMenuItem);

        //a submenu
        menu.addSeparator();
        submenu = new JMenu("A submenu");
        submenu.setMnemonic(KeyEvent.VK_S);

        menuItem = new JMenuItem("An item in the submenu");
        menuItem.setAccelerator(KeyStroke.getKeyStroke(
                KeyEvent.VK_2, ActionEvent.ALT_MASK));
        submenu.add(menuItem);

        menuItem = new JMenuItem("Another item");
        submenu.add(menuItem);
        menu.add(submenu);

        //Build second menu in the menu bar.
        menu = new JMenu("2nd Menu");
        menu.setMnemonic(KeyEvent.VK_N);
        menu.getAccessibleContext().setAccessibleDescription( "This menu does nothing");
        menuBar.add(menu);

        return menuBar;
    }


    /**
     * Returns an ImageIcon of the menu items, or null if the path was invalid.
     */
    protected static ImageIcon createImageIcon1(String path) {
        java.net.URL imgURL = MenuBarDesign1.class.getResource(path);
        if (imgURL != null) {
            return new ImageIcon(imgURL);
        } else {
            System.err.println("Couldn't find file: " + path);
            return null;
        }
    }

}
