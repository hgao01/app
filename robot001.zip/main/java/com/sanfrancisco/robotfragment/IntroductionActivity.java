package com.sanfrancisco.robotfragment;

        import android.support.v4.view.ViewPager;
        import android.support.v7.app.AppCompatActivity;

public class IntroductionActivity extends AppCompatActivity {

    private ViewPager viewPager1;

}
